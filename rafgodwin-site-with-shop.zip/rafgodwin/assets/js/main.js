(function(){
'use strict';
var $=function(s,c){return (c||document).querySelector(s)},$$=function(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))};
var root=document.documentElement;

/* ---- Terms of Service gate ---- */
var gate=$('#tos-gate'),blocked=$('#tos-blocked');
function store(v){try{localStorage.setItem('rg_tos',v)}catch(e){}}
function accepted(){try{return localStorage.getItem('rg_tos')==='accepted'}catch(e){return false}}
function unlock(){root.classList.remove('tos-lock');gate.hidden=true;blocked.hidden=true;gate.classList.remove('over');document.body.style.overflow=''}
function showGate(view){gate.hidden=false;blocked.hidden=true;gate.classList.toggle('over',!!view);$('#tos-accept').hidden=$('#tos-decline').hidden=!!view;$('#tos-close').hidden=!view;var b=$('#tos-accept');if(!view&&b)b.focus()}
function deny(){try{sessionStorage.setItem('rg_tos_declined','1')}catch(e){}store('declined');['.topbar','header.site','main','footer.site','.fab'].forEach(function(s){$$(s).forEach(function(n){n.remove()})});gate.hidden=true;blocked.hidden=false}
if(gate){
 if(accepted()){unlock()}else{root.classList.add('tos-lock');var d=false;try{d=localStorage.getItem('rg_tos')==='declined'}catch(e){}if(d)deny();else showGate(false)}
 $('#tos-accept').onclick=function(){store('accepted');unlock()};
 $('#tos-decline').onclick=deny;
 $('#tos-again').onclick=function(){store('');location.reload()};
 $('#tos-close').onclick=function(){gate.hidden=true};
 $$('.tos-open').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();showGate(true)})});
}

/* ---- mobile menu ---- */
var b=$('.burger'),m=$('.menu');
if(b&&m){b.addEventListener('click',function(){var o=m.classList.toggle('open');b.setAttribute('aria-expanded',o)});
$$('.menu a').forEach(function(a){a.addEventListener('click',function(){m.classList.remove('open')})})}

/* ---- reveal ---- */
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12});$$('.reveal').forEach(function(el){io.observe(el)})}else{$$('.reveal').forEach(function(el){el.classList.add('in')})}

/* ---- portfolio filter ---- */
var fb=$$('.filters button');
fb.forEach(function(x){x.addEventListener('click',function(){fb.forEach(function(y){y.classList.remove('on')});x.classList.add('on');var f=x.dataset.f;$$('.shot').forEach(function(s){s.classList.toggle('hide',f!=='all'&&s.dataset.c!==f)})})});

/* ---- forms: WhatsApp or email copy ---- */
var WA=window.RG_WA||'233551120109',MAIL=window.RG_EMAIL||'info@rafgodwin.com';
$$('form.f').forEach(function(f){
 var msg=$('.msg',f),bar=$('.progress i',f),via='wa';
 $$('button[type=submit]',f).forEach(function(bt){bt.addEventListener('click',function(){via=bt.dataset.via})});
 function prog(){if(!bar)return;var r=$$('[required]',f),n=r.filter(function(x){return x.value.trim()}).length;bar.style.width=Math.round(n/r.length*100)+'%'}
 f.addEventListener('input',prog);prog();
 function say(html){msg.innerHTML=html;msg.classList.add('show');msg.scrollIntoView({behavior:'smooth',block:'nearest'})}
 f.addEventListener('submit',function(e){
  e.preventDefault();
  if(e.submitter&&e.submitter.dataset.via)via=e.submitter.dataset.via;
  var ok=true;
  $$('[required]',f).forEach(function(x){var w=x.closest('.fld'),bad=!x.value.trim()||(x.type==='tel'&&x.value.replace(/\D/g,'').length<9);w.classList.toggle('bad',bad);if(bad)ok=false});
  if(!ok){var first=$('.bad',f);if(first)first.scrollIntoView({behavior:'smooth',block:'center'});say('Please fill in the highlighted fields, then send again.');return}
  var data={},lines=['*New enquiry - RafGodwin Engineering*'];
  $$('input,select,textarea',f).forEach(function(x){
   if(!x.name)return;
   if(x.type==='checkbox'||x.type==='radio'){if(x.checked){data[x.name]=(data[x.name]?data[x.name]+', ':'')+x.value}return}
   if(x.value.trim())data[x.name]=x.value.trim()});
  Object.keys(data).forEach(function(k){lines.push(k+': '+data[k])});
  lines.push('Terms of Service: Accepted');
  var text=lines.join('\n');
  if(via==='wa'){
   var url='https://wa.me/'+WA+'?text='+encodeURIComponent(text);
   var a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener';document.body.appendChild(a);a.click();a.remove();
   say('Opening WhatsApp with your request ready to send. If nothing opened, <a href="'+url+'" target="_blank" rel="noopener">tap here to send it</a>, or use &ldquo;Email a copy instead&rdquo;.');
   return}
  var mailto='mailto:'+MAIL+'?subject='+encodeURIComponent('New enquiry - RafGodwin Engineering')+'&body='+encodeURIComponent(text.replace(/\*/g,''));
  var payload=Object.assign({_subject:'New enquiry - RafGodwin Engineering',_template:'table',_captcha:'false'},data);
  if(data.Email)payload._replyto=data.Email;
  say('Sending to '+MAIL+'...');
  fetch('https://formsubmit.co/ajax/'+MAIL,{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(payload)})
   .then(function(r){if(!r.ok)throw 0;return r.json()})
   .then(function(){say('Thank you. Your request has been emailed to '+MAIL+'. We will reply within one working day.');f.reset();prog()})
   .catch(function(){say('We could not send it automatically. <a href="'+mailto+'">Tap here to email it from your mail app</a>, or use WhatsApp.')});
 })});

/* ---- hero: slow solar background (video if present, animated panels otherwise) ---- */
var bg=$('.hero-bg');
if(bg){
 var v=$('video',bg),cv=$('canvas',bg),reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 if(v&&!reduce){v.addEventListener('loadedmetadata',function(){v.playbackRate=.6});v.addEventListener('canplay',function(){bg.classList.add('has-video');v.play().catch(function(){})});v.load()}
 if(cv){
  var c=cv.getContext('2d'),W,H,t=0,dpr=Math.min(window.devicePixelRatio||1,2);
  function size(){W=cv.clientWidth;H=cv.clientHeight;cv.width=W*dpr;cv.height=H*dpr;c.setTransform(dpr,0,0,dpr,0,0)}
  size();window.addEventListener('resize',size);
  function draw(){
   c.fillStyle='#0b0e11';c.fillRect(0,0,W,H);
   var s=Math.max(54,W/20),ang=-.22,cols=Math.ceil(W/s)+8,rows=Math.ceil(H/s)+8,drift=(t*6)%s;
   c.save();c.translate(W*.55,H*.5);c.rotate(ang);c.translate(-W*.55-drift,-H*.5);
   for(var i=-4;i<cols;i++)for(var j=-4;j<rows;j++){
    var x=i*s,y=j*s*.62,sh=.5+.5*Math.sin(t*.5+i*.35+j*.5),a=.05+sh*.09;
    c.fillStyle='rgba(60,84,120,'+(.35+sh*.25)+')';c.fillRect(x+2,y+2,s-4,s*.62-4);
    c.fillStyle='rgba(217,164,65,'+a+')';c.fillRect(x+2,y+2,s-4,s*.62-4)}
   c.restore();
   var gx=W*(.2+.6*((Math.sin(t*.12)+1)/2)),g=c.createRadialGradient(gx,H*.25,10,gx,H*.25,W*.6);
   g.addColorStop(0,'rgba(255,214,140,.38)');g.addColorStop(1,'rgba(255,214,140,0)');c.fillStyle=g;c.fillRect(0,0,W,H);
   t+=.016;if(!reduce)requestAnimationFrame(draw)}
  draw()}
}
})();

/* ---- RAF: on-site assistant ----
   Behaves like a modern AI chat: thinking indicator, typed-out replies, follow-up chips, remembers the chat across pages.
   Answers come from this site's own content (no invented prices or promises).
   Optional: set window.RAF_ENDPOINT to an AI backend (POST {message, history} -> {reply}); RAF falls back to built-in answers if it fails. */
(function(){
'use strict';
var open=document.getElementById('raf-open');if(!open)return;
var WA=window.RG_WA||'233551120109',MAIL=window.RG_EMAIL||'info@rafgodwin.com',PH=window.RG_PHONE||'024 711 7982',TEL='tel:+233247117982',
MAPS='https://www.google.com/maps/search/?api=1&query=RafGodwin+Engineering+Kwashieman+Ofankor+Road+Sowutuom+Accra',SK='raf_chat_v1';
var wa=function(t){return 'https://wa.me/'+WA+'?text='+encodeURIComponent(t||'Hello RafGodwin Engineering, I have a question.')};
var hist=[],busy=false;

/* ---------- helpers ---------- */
function norm(s){return String(s||'').toLowerCase().replace(/&/g,' and ').replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim()}
function stem(w){return w.length>3?w.replace(/(es|s)$/,''):w}
function toks(s){return norm(s).split(' ').filter(Boolean).map(stem)}
function lev(a,b){if(Math.abs(a.length-b.length)>1)return 2;if(a==b)return 0;var i=0;while(i<a.length&&a[i]==b[i])i++;var x=a.slice(i),y=b.slice(i);if(x.slice(1)==y.slice(1)||x.slice(1)==y||x==y.slice(1))return 1;return 2}
var ALIAS={solor:'solar',sollar:'solar',cctvs:'cctv',camara:'camera',camaras:'camera',cameras:'camera',electrical:'electric',fense:'fence',fance:'fence',invertor:'inverter',inverta:'inverter',dumsor:'dumsor',whatsap:'whatsapp',whatsup:'whatsapp',watsapp:'whatsapp',qoute:'quote',quotation:'quote',quatation:'quote'};
function has(qt,w){w=stem(w);for(var i=0;i<qt.length;i++){var t=ALIAS[qt[i]]||qt[i];if(t==w||qt[i]==w||(w.length>=6&&t.length>=6&&lev(t,w)<2))return true}return false}
function esc(v){return String(v).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function pick(a){return a[Math.random()*a.length|0]}
/* tiny markdown: **bold**, [text](url), "- " bullets */
function md(t){var out=[],list=false;
 t.split('\n').forEach(function(l){var li=/^- /.test(l);
  if(li&&!list){out.push('<ul>');list=true}if(!li&&list){out.push('</ul>');list=false}
  var h=esc(li?l.slice(2):l).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\[([^\]]+)\]\(([^)\s]+)\)/g,function(m,a,u){var ext=/^https?:/.test(u);return '<a href="'+u+'"'+(ext?' target="_blank" rel="noopener"':'')+'>'+a+'</a>'});
  out.push(li?'<li>'+h+'</li>':(h?'<p>'+h+'</p>':''))});
 if(list)out.push('</ul>');return out.join('')}
function R(text,chips,id){return{text:text,chips:chips||[],id:id||''}}

/* ---------- knowledge ---------- */
var ACT=[{t:'Call now',h:TEL},{t:'WhatsApp',h:wa()},{t:'Free quote',h:'quote.html'}];
var DEF=['Get a quote','Solar options','CCTV','Opening hours','Location','Talk to a person'];
var QUOTE_W=wa('Hello, I would like a free quote.');

function answer(q){
 var n=norm(q),qt=toks(q),
 A=function(){for(var i=0;i<arguments.length;i++)if(has(qt,arguments[i]))return true;return false},
 P=function(re){return re.test(n)};

 /* small talk */
 if(/^(hi|hello|hey|hiya|good (morning|afternoon|evening)|howdy|yo)\b/.test(n)&&n.split(' ').length<5)
  return R('Hello! I\u2019m **RAF**, RafGodwin Engineering\u2019s assistant. Ask me about our services, quotes, location or opening hours.',['Get a quote','Solar options','Opening hours'],'hi');
 if(P(/\b(thank|thanks|thx|cheers|appreciate)\b/))return R(pick(['You\u2019re welcome! Anything else I can help with?','Happy to help! Ask me anything else about RafGodwin Engineering.']),['Get a quote','Opening hours'],'ty');
 if(P(/\b(bye|goodbye|see you|cya)\b/))return R('Thanks for stopping by. We\u2019re here whenever you need us.',[],'bye');
 if(P(/\b(who|what) are you\b|your name|who is raf|what is raf|are you (a )?(bot|ai|human|real)|talking to/))
  return R('I\u2019m **RAF**, the virtual assistant for RafGodwin Engineering. I\u2019m automated, and I answer from this website\u2019s information: our services, quotes, location and hours. For anything I can\u2019t answer, our team is a call or WhatsApp away.',ACT,'about-raf');
 if(P(/\bhow are you\b/))return R('Doing great, thanks for asking! What would you like to know about our smart home, security or solar services?',DEF.slice(0,3),'hru');

 /* contact / talk to a person */
 if((A('phone','call','number','contact','reach','whatsapp','telephone','email','mail','person','human','agent','speak','talk','engineer')||P(/get in touch|customer care/))&&!A('quote','price','cost')&&!P(/\bhow long\b|(control|view|monitor|watch|check|manage).*(phone|app|remote|mobile)|from my phone|mobile app/)){
  if(P(/e ?mail|mail us/)&&!A('phone','call','whatsapp'))return R('You can email us at [info@rafgodwin.com](mailto:'+MAIL+'). Every form on this site also has an \u201cEmail a copy instead\u201d button. For a faster reply, WhatsApp is usually quickest.',ACT,'contact');
  return R('You can reach our team here:\n- **Call:** [024 711 7982]('+TEL+')\n- **WhatsApp:** [+233 55 112 0109]('+wa()+')\n- **Email:** [info@rafgodwin.com](mailto:'+MAIL+')\nWe reply within one working day, and usually much faster on WhatsApp.',ACT,'contact')}

 /* coverage areas */
 if(P(/(do|can|will) you (travel|come|operate|work|install|serve) (to|in|outside|across|around|at)\b|which (areas|regions|towns|cities)|coverage|nationwide|outside accra|all over ghana|across ghana|other regions?|\b(kumasi|tema|kasoa|takoradi|tamale|cape coast|koforidua|weija|madina|adenta|spintex|east legon|achimota|sunyani)\b/))
  return R('We install **across Ghana**. Our quote form lists Sowutuom/Kwashieman, Ofankor/Achimota, Accra Central, East Legon/Airport, Tema/Spintex, Madina/Adenta, Kasoa/Weija and Kumasi, plus \u201cOther region in Ghana\u201d. Tell us your location in the [quote form](quote.html) and we\u2019ll confirm a survey date.',[{t:'Free quote',h:'quote.html'},{t:'WhatsApp',h:QUOTE_W},'Location'],'areas');

 /* location */
 if(A('where','location','address','direction','map','visit','located','sowutuom','kwashieman','ofankor')||P(/find (you|us)|how (do|can) i get (to|there|here)|way to you|(your|the|come to) (office|shop|showroom)/))
  return R('Our office is at **JP9F+Q85, Kwashieman Ofankor Road, Sowutuom, Accra**.\n- [Open in Google Maps]('+MAPS+')\nBest to call or WhatsApp before you visit so we can have an engineer ready.',[{t:'Directions',h:MAPS},{t:'Call now',h:TEL},'Opening hours'],'loc');

 /* hours */
 if(A('hour','open','close','closing','sunday','saturday','monday','tuesday','wednesday','thursday','friday','weekend','opening')||P(/what time|until when|till when|working days/))
  return R('Our hours:\n- **Monday to Friday:** 8:00 am to 6:00 pm\n- **Saturday:** 9:00 am to 4:00 pm\n- **Sunday:** closed\nOutside these hours you can still [WhatsApp us]('+wa()+') or send a [quote request](quote.html) and we\u2019ll reply within one working day.',[{t:'Call now',h:TEL},{t:'WhatsApp',h:wa()},'Location'],'hours');

 /* things the site does not say: never invent them */
 if(P(/\b(warrant\w*|guarantee\w*|financ\w*|instal+ment\w*|payment plan\w*|pay (in|by|with)|momo|mobile money|credit|loan|discount\w*|brands?|certificat\w*|licen[sc]\w*|insur\w*|job|jobs|career\w*|hiring|vacanc\w*|24 ?7|emergency|after hours|same day|turnaround|lead time|spare parts?|second ?hand|refurbish\w*)\b/)||P(/how long (does|will|do|would) .*(take|install|complete|finish)|how soon|how fast/))
  return R('I don\u2019t have that detail on the website, and I don\u2019t want to guess. Our team can tell you quickly:',ACT,'unknown');

 /* pricing / quotes */
 if(A('price','pricing','cost','quote','estimate','budget','cheap','expensive','afford','charge','fee','rate')||P(/how much|free survey|site visit|consultation/))
  return R('We don\u2019t publish fixed prices because every property is different. Instead we do a **free site survey**, then send an **itemised quotation**, so you only pay for what your property needs. It\u2019s no obligation, with clear pricing and no hidden costs.\nQuotes are non-binding until confirmed in writing after the survey. Our [quote form](quote.html) lets you pick a budget range (from under GH\u20b55,000 to above GH\u20b5150,000) so we can match you with the right engineer.',[{t:'Request a quote',h:'quote.html'},{t:'WhatsApp',h:QUOTE_W},'How it works'],'pricing');

 /* phone control / internet / maintenance / lifespan */
 if(P(/(control|view|monitor|watch|check|manage).*(phone|app|remote|remotely|anywhere|mobile)|from my phone|mobile app|\bapp\b/))
  return R('Yes. Lighting, locks, gates, cameras and solar monitoring can all be viewed and controlled **from your phone**, and many by voice. Remote viewing works on iOS and Android.',['Internet needs','Smart home','CCTV'],'app');
 if(A('internet','wifi','bandwidth','mbps','connection','broadband','router')||P(/wi ?fi|data connection/))
  return R('Remote viewing needs a stable connection. A typical home needs roughly **5 to 10 Mbps upload** for a few cameras. **Local control and recording keep working** even when the internet is down.',['CCTV','Blackout backup'],'internet');
 if(P(/how long (will|do|does|would).*(last|solar|batter|panel|inverter)|lifespan|life span|last for|durab|replace(ment)? (my )?batter/))
  return R('As a guide: quality **solar panels last 20+ years**, **lithium batteries typically 8 to 12 years** depending on use, and **inverters 8 to 10 years**. Proper sizing and care extend life.',['Maintenance','Solar options'],'lifespan');
 if(P(/maintenance|maintain|servicing|repair|clean(ing)?|care plan|aftercare|after ?install|inspect|support|service plan/))
  return R('We recommend:\n- **Cameras, locks and fences:** inspection about every 6 months\n- **Solar panels:** cleaning every 3 to 6 months (more often in harmattan dust)\n- **Batteries:** a check once a year\nWe offer **care plans** and we support you after installation. More in the [FAQs](faq.html).',[{t:'Ask about a care plan',h:wa('Hello, I would like to ask about a care plan.')},'Get a quote'],'maintenance');

 if(P(/blackout|dumsor|power (cut|outage|failure)|outage|load shedding|\bups\b|backup|back up|lights? off|grid fail/))
  return R('Yes, we design systems to **keep working during blackouts**. We add UPS or solar-battery backup so cameras, routers, locks, gate motors and electric-fence energisers stay on, and our solar packages keep essentials like lights, TV, fans and Wi-Fi running (fridge and pump from the Comfort package up). Local control and recording also continue when the internet is down. See [Solar](solar.html).',[{t:'Request a quote',h:'quote.html'},'Solar options'],'backup');
 /* process */
 if(A('survey','process','steps','started','begin')||P(/how (does|do) (it|this|the process|ordering)|how it works|what happens (after|next|when i)|next step|get started|where do i start|how do i (start|order|book|apply)/))
  return R('It\u2019s four simple steps:\n- **Submit:** complete the short [quote form](quote.html)\n- **Survey:** we visit and measure, free\n- **Quote:** you receive an itemised proposal\n- **Install:** our engineers deliver the system and train you\nWe reply within one working day.',[{t:'Request a quote',h:'quote.html'},{t:'WhatsApp',h:QUOTE_W}],'process');

 /* services: specific topics */
 var solar=A('solar','panel','inverter','battery','renewable','hybrid','offgrid','lithium','grid','energy','electricity')||P(/off grid/);
 if(P(/\b(commercial|business|businesses|company|factory|school|church|warehouse|shop|office|energy audit|audit|payback|tariff)\b/)&&solar&&!P(/our office|your office/))
  return R('For businesses we offer:\n- **Energy audit and load profiling**\n- **Large rooftop and ground-mount solar**\n- **Hybrid systems with generator integration**\n- **Monitoring dashboards and maintenance contracts**\nWe analyse your consumption, design the right solar and storage system, and show the payback before you invest. See [Commercial Energy](commercial-energy.html).',[{t:'Request a quote',h:'quote.html'},{t:'WhatsApp',h:QUOTE_W},'Solar options'],'commercial');
 if(solar&&P(/residential|home solar|house|household|package|essentials|comfort|whole home|my home|apartment|flat/))
  return R('Our residential solar packages:\n- **Essentials:** lights, TV, fans, Wi-Fi\n- **Comfort:** adds fridge, water pump and selected AC\n- **Whole-home hybrid** with battery storage\n- **Off-grid systems** for remote properties\nWe survey your appliances and roof, recommend a package, and show the expected backup time before you commit. See [Residential Solar Packages](residential-solar.html).',[{t:'Request a quote',h:'quote.html'},'Blackout backup','Commercial solar'],'residential');
 if(solar)
  return R('We design **hybrid, off-grid and grid-tied** solar around your actual load, so essentials stay on and bills come down:\n- Honest load analysis and system sizing\n- Quality panels, inverters and batteries\n- Neat roof mounting and safe cabling\nSee [Solar](solar.html), [Residential Packages](residential-solar.html) and [Commercial Energy](commercial-energy.html).',[{t:'Request a quote',h:'quote.html'},'Home packages','Commercial solar','Blackout backup'],'solar');
 if(A('cctv','camera','surveillance','footage','dvr','nvr','recording','playback')||P(/night vision|security camera/))
  return R('Our CCTV systems include:\n- **HD and night-vision cameras**\n- **Live view and playback** on iOS and Android\n- **Cloud and local recorder** storage\n- **Motion alerts** and smart detection\n- **UPS or solar backup** so cameras stay on\nWe plan camera positions for real coverage, cable cleanly and set up secure remote viewing. See [CCTV & Surveillance](cctv.html).',[{t:'Request a quote',h:'quote.html'},'Internet needs','Blackout backup'],'cctv');
 if(A('fence','fencing','perimeter','energiser','energizer','electric')||P(/electric fence/)){
  if(P(/safe|danger|shock|harm|kill|hurt/))return R('Yes, electric fencing is safe **when installed to standard**. Energisers deliver short, high-voltage, low-current pulses, with correct earthing, warning signs and clearances, which is how we install every fence. See [Electric Fencing](electric-fencing.html).',[{t:'Request a quote',h:'quote.html'},'CCTV'],'fence-safe');
  return R('Our electric fences are installed to safety standards:\n- **Wall-top and freestanding** systems\n- **Alarm-linked energisers** with alerts\n- **Safe earthing** and warning signage\n- **Solar or battery backup** for continuous protection\nThey can also be paired with cameras to verify intrusions. See [Electric Fencing](electric-fencing.html).',[{t:'Request a quote',h:'quote.html'},'Is fencing safe?','CCTV'],'fence')}
 if(A('lock','fingerprint','biometric','keyless','gate','intercom','access','keypad','pin')||P(/smart lock|access control/))
  return R('We fit smart entry systems:\n- **Fingerprint, PIN, card and app** unlock\n- **Remote lock status** and access history\n- **Temporary codes** for guests and staff\n- **Sliding and swing gate motors** with remote and app control\n- **Multi-user access control** for estates and offices\nSee [Smart Locks & Gates](smart-locks.html).',[{t:'Request a quote',h:'quote.html'},'CCTV','Electric fence'],'locks');
 if(P(/smart home|home automation|automation|automate|automated|lighting|\blights?\b|appliances?|voice|alexa|google home|curtains?|climate|aircon|air condition|\bac\b|geyser|sockets?|\bpump\b|scenes?/))
  return R('We connect lighting, appliances, air-conditioning, gates and security into **one app or voice-controlled system**:\n- Scene-based lighting and dimming\n- Smart appliance and socket control (geysers, pumps)\n- Climate and AC scheduling to cut power bills\n- Voice and app control, with local backup when the internet drops\nSee [Smart Home & Automation](smart-home.html).',[{t:'Request a quote',h:'quote.html'},'Internet needs','Smart locks'],'smarthome');
 if(A('security','secure','protect','safety','burglar','theft','thief','intruder','alarm','break'))
  return R('We build security **in layers**: deter at the perimeter, detect on approach, verify with cameras and control every entry. That means electric fencing, HD CCTV, biometric locks and automated gates all working together. See [Security & Access Control](security.html).',[{t:'Request a quote',h:'quote.html'},'CCTV','Electric fence','Smart locks'],'security');

 /* overview */
 if(A('service','offer','provide','sell','products')||P(/what do you do|what can you do/))
  return R('We\u2019re an Accra-based team with **three core service lines**:\n- **Smart Home & Automation:** [see more](smart-home.html)\n- **Security & Access Control:** CCTV, electric fencing, smart locks and gates ([overview](security.html))\n- **Solar & Renewable Energy:** residential and commercial ([overview](solar.html))\nWhich one would you like to hear about?',['Solar options','CCTV','Electric fence','Smart locks'],'services');

 /* company / social / reviews / portfolio / policies */
 if(P(/who (made|built|designed|created|developed) (this|the|your)? ?(website|site)|web ?developer|website by/))
  return R('This website was designed and developed by Clemence, [+233 55 867 7511](tel:+233558677511).',[],'dev');
 if(A('about','company','clients','experience','mission','values','founded','history','established','trust','legit')||P(/who (are|is) (rafgodwin|raf godwin)/))
  return R('RafGodwin Engineering is an **Accra-based engineering firm** delivering smart home automation, security and solar systems, with **900+ clients served**. Our mission is to modernise and protect Ghanaian homes and businesses by making intelligent, secure and energy-independent living accessible. We stand for integrity, craftsmanship, reliability and service. More on the [About page](about.html).',['Get a quote','Our services'],'about');
 if(A('review','rating','testimonial','feedback','google','reputation','stars'))
  return R('We don\u2019t publish ratings on this site, but you can read what clients say on Google. If you\u2019ve worked with us, please [leave a Google review](testimonials.html) in under a minute.',[{t:'Reviews page',h:'testimonials.html'}],'reviews');
 if(A('instagram','tiktok','social','insta','follow'))
  return R('You\u2019ll find our Instagram and TikTok links in the footer and on the [Contact page](contact.html).',['Talk to a person'],'social');
 if(A('portfolio','projects','examples','gallery','photos','pictures','completed')||P(/past work|your work/))
  return R('See some of our completed installations, like a rooftop solar array and a smart lock installation in Accra, on the [Portfolio page](portfolio.html).',[{t:'Portfolio',h:'portfolio.html'},'Get a quote'],'portfolio');
 if(A('terms','privacy','policy','data','personal','legal','consent','cookie'))
  return R('In short: the site\u2019s content is general information; quotes are non-binding until confirmed in writing after a site survey; we use your details only to respond to you by WhatsApp, phone or email, and we do **not sell your data**. Final specifications, prices and timelines are agreed in your signed quotation. You can reopen the full terms from the footer link \u201cTerms of Service\u201d.',[],'legal');
 if(A('faq','question','faqs'))
  return R('The [FAQs](faq.html) cover maintenance, internet needs, blackouts, battery life, electric fence safety and phone control. You can also just ask me.',DEF.slice(0,3),'faq');

 /* fallback */
 if(qt.length<=3)return R('I couldn\u2019t find that on our website. Our team will be glad to help, so please ask them directly.',ACT,'nomatch');
 return R('I\u2019m not sure I have that one. I can help with **services** (smart home, CCTV, fencing, locks, solar), **quotes**, **location** and **opening hours**. For anything else, our team is happy to help.',DEF.slice(0,3).concat(ACT.slice(0,2)),'fallback');
}

/* compound questions: "do you do CCTV and what time do you open?" -> answer each part */
function respond(t){
 var parts=t.split(/\?+\s*|\s+(?:and|also|plus)\s+(?=(?:what|how|do|does|can|where|when|is|are|which|who|will)\b)/i).map(function(x){return x.trim()}).filter(function(x){return x.split(/\s+/).length>=2});
 if(parts.length<2||parts.length>3)return answer(t);
 var seen={},rs=parts.map(answer).filter(function(r){if(/^(fallback|nomatch)$/.test(r.id)||seen[r.id])return false;seen[r.id]=1;return true});
 if(rs.length<2)return rs.length?rs[0]:answer(t);
 return R(rs.map(function(r){return r.text}).join('\n\n'),rs[rs.length-1].chips,rs.map(function(r){return r.id}).join('+'))
}

/* ---------- UI ---------- */
var wrap=document.createElement('div');wrap.className='raf';wrap.setAttribute('role','dialog');wrap.setAttribute('aria-label','Chat with RAF');
wrap.innerHTML='<div class="raf-h"><img src="assets/img/logo-mark.png" alt=""><div><b>RAF <span>Assistant</span></b><small>Smart home experts</small></div><button type="button" aria-label="Close chat">&times;</button></div><div class="raf-log" role="log" aria-live="polite"></div><div class="raf-chips"></div><form class="raf-f"><input type="text" enterkeyhint="send" placeholder="Ask about services, quotes, hours" aria-label="Your question" autocomplete="off" maxlength="300"><button type="submit">Send</button></form>';
document.body.appendChild(wrap);
var log=wrap.querySelector('.raf-log'),chips=wrap.querySelector('.raf-chips'),inp=wrap.querySelector('input'),sendBtn=wrap.querySelector('.raf-f button');
function scroll(){log.scrollTop=log.scrollHeight}
function save(){try{sessionStorage.setItem(SK,JSON.stringify({h:hist.slice(-40),o:wrap.classList.contains('open')}))}catch(e){}}
function add(html,user){var d=document.createElement('div');d.className='raf-m'+(user?' u':'');if(user)d.textContent=html;else d.innerHTML=html;log.appendChild(d);scroll();return d}
function setChips(list){
 chips.innerHTML='';
 (list&&list.length?list:DEF).forEach(function(c){
  if(typeof c==='object'){var a=document.createElement('a');a.href=c.h;a.textContent=c.t;if(/^https?:/.test(c.h)){a.target='_blank';a.rel='noopener'}chips.appendChild(a)}
  else{var b=document.createElement('button');b.type='button';b.textContent=c;b.onclick=function(){ask(c)};chips.appendChild(b)}});
 chips.scrollLeft=0}
var STATUS={pricing:'Checking how quotes work\u2026',loc:'Finding our location\u2026',hours:'Checking our hours\u2026',solar:'Looking up solar options\u2026',residential:'Looking up solar packages\u2026',commercial:'Looking up business energy\u2026',cctv:'Checking camera options\u2026',fence:'Checking fence details\u2026',locks:'Checking entry systems\u2026',smarthome:'Checking smart home options\u2026',security:'Checking security options\u2026',backup:'Checking backup power\u2026',process:'Checking the steps\u2026',areas:'Checking coverage\u2026'};
function think(id){
 var d=document.createElement('div');d.className='raf-m think';
 d.innerHTML='<span class="raf-dots" aria-hidden="true"><i></i><i></i><i></i></span><span class="raf-st">Thinking\u2026</span>';
 log.appendChild(d);scroll();
 var st=d.querySelector('.raf-st'),steps=['Thinking\u2026',STATUS[id]||'Reading the site\u2026','Putting my answer together\u2026'],i=0;
 var t=setInterval(function(){i=Math.min(i+1,steps.length-1);st.textContent=steps[i]},650);
 d.stop=function(){clearInterval(t);d.remove()};return d}
function stream(el,html,done){
 var parts=html.split(/(<[^>]+>)/).filter(Boolean),ch=[];
 parts.forEach(function(p){if(p[0]==='<')ch.push(p);else p.split(/(\s+)/).forEach(function(w){if(w)ch.push(w)})});
 var i=0,out='',reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 if(reduce){el.innerHTML=html;done();return}
 el.classList.add('typing');
 (function step(){var n=0;while(i<ch.length&&n<3){out+=ch[i];if(ch[i][0]!=='<'&&!/^\s+$/.test(ch[i]))n++;i++}
  el.innerHTML=out;scroll();
  if(i<ch.length)setTimeout(step,22+Math.random()*28);else{el.classList.remove('typing');done()}})()}
function reply(r){
 var html=md(r.text),th=think(r.id),wait=Math.min(2200,Math.max(1100,700+r.text.length*3));
 return new Promise(function(res){setTimeout(function(){th.stop();var m=add('');
  stream(m,html,function(){hist.push({r:'bot',t:html,c:r.chips});save();setChips(r.chips);res()})},wait)})}
function setBusy(v){busy=v;sendBtn.disabled=v;wrap.classList.toggle('busy',v);chips.classList.toggle('dis',v)}
function ask(q){
 q=String(q||'').trim();if(!q||busy)return;
 add(q,true);hist.push({r:'user',t:q,u:1});save();inp.value='';setBusy(true);
 var fin=function(){setBusy(false)};
 if(window.RAF_ENDPOINT){
  var th=think('');
  fetch(window.RAF_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:q,history:hist.slice(-10).map(function(h){return{role:h.r==='bot'?'assistant':'user',text:h.r==='bot'?h.t.replace(/<[^>]+>/g,''):h.t}})})})
   .then(function(r){return r.ok?r.json():Promise.reject()}).then(function(j){if(!j.reply)throw 0;th.stop();var m=add(''),h=md(j.reply);stream(m,h,function(){hist.push({r:'bot',t:h});save();fin()})})
   .catch(function(){th.stop();reply(respond(q)).then(fin)});
  return}
 var r;try{r=respond(q)}catch(e){r=R('Sorry, something went wrong on my side. Please try again, or reach our team directly.',ACT,'err')}
 reply(r).then(fin)}
wrap.querySelector('form').onsubmit=function(e){e.preventDefault();ask(inp.value)};

var mobile=function(){return window.matchMedia('(max-width:600px)').matches};
function fit(){var vv=window.visualViewport;if(mobile()&&vv){wrap.style.setProperty('--rafh',vv.height+'px');wrap.style.transform='translateY('+vv.offsetTop+'px)';scroll()}else{wrap.style.removeProperty('--rafh');wrap.style.transform=''}}
if(window.visualViewport){visualViewport.addEventListener('resize',fit);visualViewport.addEventListener('scroll',fit)}
function welcome(){var html=md('Hi, I\u2019m **RAF**. Ask me anything about RafGodwin Engineering: services, quotes, location or opening hours.');add(html);hist.push({r:'bot',t:html,c:DEF});setChips(DEF)}
function toggle(f){
 var o=f===undefined?!wrap.classList.contains('open'):f;
 wrap.classList.toggle('open',o);document.body.classList.toggle('raf-lock',o&&mobile());open.classList.toggle('hide',o&&mobile());fit();
 if(o){if(!log.children.length)welcome();if(!mobile())setTimeout(function(){inp.focus()},50);scroll()}
 save()}
open.onclick=function(){toggle()};wrap.querySelector('.raf-h button').onclick=function(){toggle(false);open.focus()};
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&wrap.classList.contains('open'))toggle(false)});

/* restore chat when moving between pages */
(function(){var s=null;try{s=JSON.parse(sessionStorage.getItem(SK)||'null')}catch(e){}
 if(s&&s.h&&s.h.length){hist=s.h;hist.forEach(function(m){add(m.t,m.r==='user')});var last=hist[hist.length-1];if(last.r==='bot')setChips(last.c);else setChips(DEF)}
 else setChips(DEF);
 if(s&&s.o)toggle(true)})();
})();

/* ---- shop link cart count (all pages) ---- */
(function(){try{var c=JSON.parse(localStorage.getItem('rg_cart'))||[],n=c.reduce(function(a,x){return a+x.qty},0);if(!n)return;
document.querySelectorAll('.menu a[href="shop.html"]').forEach(function(a){var i=document.createElement('i');i.className='cartc';i.textContent=n;a.appendChild(i)})}catch(e){}})();
