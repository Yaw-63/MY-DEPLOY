(function(){'use strict';
var $=function(s,c){return(c||document).querySelector(s)},$$=function(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))};
var STATUS={new:'New',confirmed:'Confirmed',out_for_delivery:'Out for delivery',delivered:'Delivered',cancelled:'Cancelled'};
var orders=[],products=[],stats=null,ofilter='',oq='',lastNew=null,poll=null,editing=null,imgs=[];
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function ghs(p){return 'GH\u20B5'+(p/100).toLocaleString('en-GH',{minimumFractionDigits:2,maximumFractionDigits:2})}
function img(u){return u?(u.charAt(0)==='/'?u:'/'+u):'/assets/img/logo-mark.png'}
function bg(u){return "background-image:url('"+esc(img(u))+"')"}
function when(t){var d=new Date(t*1000);return d.toLocaleDateString('en-GB',{day:'numeric',month:'short'})+' '+d.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'})}
function toast(m){var t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(function(){t.classList.remove('show')},2400)}
function api(path,method,body){
  return fetch('/api/admin/'+path,{method:method||'GET',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined,credentials:'same-origin'})
  .then(function(r){return r.json().catch(function(){return{}}).then(function(j){
    if(r.status===401&&path!=='login'){showLogin();throw new Error('Please log in')}
    if(!r.ok)throw new Error(j.error||'Something went wrong');return j})})
}

/* ---- auth ---- */
function showLogin(){clearInterval(poll);$('#app').hidden=true;$('#login').hidden=false;$('#pw').value='';setTimeout(function(){$('#pw').focus()},50)}
function showApp(){$('#login').hidden=true;$('#app').hidden=false;refresh(true);clearInterval(poll);poll=setInterval(function(){refresh(false)},25000)}
$('#lf').addEventListener('submit',function(e){e.preventDefault();$('#lerr').textContent='';
  api('login','POST',{password:$('#pw').value}).then(showApp).catch(function(er){$('#lerr').textContent=er.message})});
$('#logout').onclick=function(){api('logout','POST',{}).catch(function(){}).then(showLogin)};

/* ---- tabs ---- */
function tab(n){$$('#tabs button').forEach(function(b){b.classList.toggle('on',b.dataset.tab===n)});['overview','orders','products'].forEach(function(t){$('#t-'+t).hidden=t!==n});if(n==='orders')ordersView();}
$('#tabs').addEventListener('click',function(e){var b=e.target.closest('button');if(b)tab(b.dataset.tab)});

/* ---- data ---- */
function refresh(first){
  return Promise.all([api('stats'),api('orders'),api('products')]).then(function(r){
    var prev=lastNew;stats=r[0];orders=r[1].orders;products=r[2].products;
    if(prev!==null&&stats.newest_order>prev){toast('New order received!');try{document.title='(New) Admin | RafGodwin'}catch(e){}}
    lastNew=stats.newest_order;
    var n=stats.counts.new;$('#newc').hidden=!n;$('#newc').textContent=n;
    renderOverview();ordersView();productsView();
  }).catch(function(e){if(first&&e.message!=='Please log in')toast(e.message)})
}
function renderOverview(){
  var c=stats.counts;
  $('#stats').innerHTML=[['New orders',c.new,c.new?'hot':''],['To deliver',c.confirmed+c.out_for_delivery,''],['Delivered',c.delivered,''],['This month (confirmed+)',ghs(stats.revenue_month),''],['Products',stats.products,'']]
   .map(function(s){return '<div class="stat '+s[2]+'"><b>'+s[1]+'</b><span>'+s[0]+'</span></div>'}).join('');
  $('#lowbox').hidden=!stats.low_stock.length;
  $('#low').innerHTML=stats.low_stock.map(function(p){return '<div class="it"><span>'+esc(p.name)+'</span><b class="lowtxt">'+(p.stock?p.stock+' left':'Sold out')+'</b></div>'}).join('');
  $('#latest').innerHTML=orders.length?orders.slice(0,5).map(function(o){return orderRow(o,false)}).join(''):'<div class="empty">No orders yet. They will appear here the moment a customer checks out.</div>';
}

/* ---- orders ---- */
function orderRow(o,open){
  var items=o.items.map(function(i){return i.qty+' x '+i.name}).join(', ');
  var h='<div class="ord'+(o.status==='new'?' isnew':'')+'" data-o="'+o.id+'"><div class="oh" data-toggle><div><b>'+esc(o.code)+'</b><small>'+when(o.created_at)+'</small></div><div><b>'+esc(o.name)+'</b><small>'+esc(items.length>70?items.slice(0,70)+'...':items)+'</small></div><div class="tot">'+ghs(o.total)+'</div><div><span class="st '+o.status+'">'+STATUS[o.status]+'</span></div></div>';
  if(open){
    var phone=o.phone.replace(/\D/g,'');if(phone.charAt(0)==='0')phone='233'+phone.slice(1);
    var msg='Hello '+o.name.split(' ')[0]+', this is RafGodwin Engineering about your order '+o.code+'.';
    h+='<div class="od" hidden><div><h4>Items</h4>'+o.items.map(function(i){return '<div class="it"><i style="'+bg(i.image)+'"></i><span>'+esc(i.name)+'<br><small>'+ghs(i.price)+' each</small></span><b>'+i.qty+' x</b></div>'}).join('')+'<div class="it"><span><b>Total</b></span><b>'+ghs(o.total)+'</b></div></div>'
    +'<div><h4>Customer</h4><p><b>'+esc(o.name)+'</b><br><a href="tel:'+esc(o.phone)+'">'+esc(o.phone)+'</a>'+(o.email?'<br>'+esc(o.email):'')+'</p><h4>Delivery</h4><p>'+esc(o.address)+(o.area?'\n'+esc(o.area):'')+'</p><h4>Payment</h4><p>'+esc(o.payment_label)+'</p>'+(o.notes?'<h4>Customer note</h4><p>'+esc(o.notes)+'</p>':'')
    +'<h4>Status</h4><div class="acts"><select data-status>'+Object.keys(STATUS).map(function(k){return '<option value="'+k+'"'+(k===o.status?' selected':'')+'>'+STATUS[k]+'</option>'}).join('')+'</select><a class="wa" target="_blank" rel="noopener" href="https://wa.me/'+phone+'?text='+encodeURIComponent(msg)+'">WhatsApp customer</a></div>'
    +'<h4 style="margin-top:12px">Your private note</h4><textarea data-note>'+esc(o.admin_note)+'</textarea><div class="acts"><button class="btn" data-save>Save changes</button></div></div></div>';
  }
  return h+'</div>';
}
function ordersView(){
  var counts={};orders.forEach(function(o){counts[o.status]=(counts[o.status]||0)+1});
  $('#ofilter').innerHTML=[''].concat(Object.keys(STATUS)).map(function(k){return '<button data-f="'+k+'" class="'+(ofilter===k?'on':'')+'">'+(k?STATUS[k]+(counts[k]?' ('+counts[k]+')':''):'All ('+orders.length+')')+'</button>'}).join('');
  var l=orders.filter(function(o){return(!ofilter||o.status===ofilter)&&(!oq||(o.code+' '+o.name+' '+o.phone).toLowerCase().indexOf(oq)>-1)});
  var openId=$('#olist .ord.open')?+$('#olist .ord.open').dataset.o:null;
  $('#olist').innerHTML=l.length?l.map(function(o){return orderRow(o,true)}).join(''):'<div class="panel empty">No orders here yet.</div>';
  if(openId){var el=$('#olist .ord[data-o="'+openId+'"]');if(el){el.classList.add('open');$('.od',el).hidden=false}}
}
$('#ofilter').addEventListener('click',function(e){var b=e.target.closest('button');if(b){ofilter=b.dataset.f;ordersView()}});
$('#osearch').addEventListener('input',function(e){oq=e.target.value.toLowerCase().trim();ordersView()});
document.addEventListener('click',function(e){
  var t=e.target.closest('[data-toggle]');
  if(t){var o=t.parentNode,d=$('.od',o);if(d){d.hidden=!d.hidden;o.classList.toggle('open',!d.hidden)}else{tab('orders');}return}
  var s=e.target.closest('[data-save]');
  if(s){var ord=s.closest('.ord'),id=+ord.dataset.o;s.disabled=true;
    api('orders/'+id,'PUT',{status:$('[data-status]',ord).value,admin_note:$('[data-note]',ord).value}).then(function(){toast('Order updated');return refresh(false)}).catch(function(er){toast(er.message)}).then(function(){s.disabled=false})}
});
/* overview "latest" rows have no detail panel: clicking goes to Orders */

/* ---- products ---- */
function productsView(){
  var dl=[];products.forEach(function(p){if(dl.indexOf(p.category)<0)dl.push(p.category)});
  ['CCTV Cameras','Smart Locks','Solar & Inverters','Batteries','Electric Fencing','Gate Motors','Accessories'].forEach(function(c){if(dl.indexOf(c)<0)dl.push(c)});
  $('#cats').innerHTML=dl.map(function(c){return '<option value="'+esc(c)+'">'}).join('');
  $('#ptable').innerHTML=products.length?'<thead><tr><th></th><th>Product</th><th>Price</th><th>Stock</th><th>Status</th><th></th></tr></thead><tbody>'+products.map(function(p){
    return '<tr><td><div class="th" style="'+bg(p.images[0])+'"></div></td><td><b>'+esc(p.name)+'</b><br><small style="color:var(--muted)">'+esc(p.category)+'</small></td><td>'+ghs(p.price)+'</td><td>'+(p.stock==null?'<span class="off">Not tracked</span>':p.stock<=3?'<span class="lowtxt">'+p.stock+'</span>':p.stock)+'</td><td>'+(p.active?'Live':'<span class="off">Hidden</span>')+'</td><td><div class="acts"><button class="ghost" data-edit="'+p.id+'">Edit</button><button class="ghost" data-del="'+p.id+'">Delete</button></div></td></tr>'}).join('')+'</tbody>'
   :'<tbody><tr><td class="empty">No products yet. Click &ldquo;Add product&rdquo; to upload your first one.</td></tr></tbody>';
}
function paintImgs(){
  $('#imgs').innerHTML=imgs.map(function(u,i){return u==='busy'?'<div class="busy">Uploading</div>':'<div style="'+bg(u)+'"><button type="button" data-rmimg="'+i+'" aria-label="Remove photo">&times;</button></div>'}).join('');
}
function openForm(p){
  editing=p?p.id:null;var f=$('#pf');f.reset();$('#perr').textContent='';
  $('#pmt').textContent=p?'Edit product':'Add product';
  f.name.value=p?p.name:'';f.price.value=p?(p.price/100).toFixed(2):'';f.stock.value=p&&p.stock!=null?p.stock:'';
  f.category.value=p?p.category:'';f.description.value=p?p.description:'';f.active.checked=p?p.active:true;
  imgs=p?p.images.slice():[];paintImgs();$('#pmodal').hidden=false;f.name.focus();
}
$('#addp').onclick=function(){openForm(null)};
$('#pmodal').addEventListener('click',function(e){if(e.target===this||e.target.hasAttribute('data-x'))this.hidden=true;var r=e.target.closest('[data-rmimg]');if(r){imgs.splice(+r.dataset.rmimg,1);paintImgs()}});
document.addEventListener('keydown',function(e){if(e.key==='Escape')$('#pmodal').hidden=true});
$('#ptable').addEventListener('click',function(e){
  var ed=e.target.closest('[data-edit]'),dl=e.target.closest('[data-del]');
  if(ed)openForm(products.filter(function(p){return p.id==ed.dataset.edit})[0]);
  if(dl){var p=products.filter(function(x){return x.id==dl.dataset.del})[0];
    if(confirm('Delete "'+p.name+'"? Past orders keep their details. To just hide it, edit and untick "Visible in the shop".'))api('products/'+p.id,'DELETE').then(function(){toast('Deleted');return refresh(false)}).catch(function(er){toast(er.message)})}
});
function shrink(file){
  return new Promise(function(res,rej){
    var r=new FileReader();r.onerror=function(){rej(new Error('Could not read image'))};
    r.onload=function(){var im=new Image();im.onerror=function(){rej(new Error('That file is not a usable image'))};
      im.onload=function(){var m=1400,s=Math.min(1,m/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*s);c.height=Math.round(im.height*s);
        var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);res(c.toDataURL('image/jpeg',.86))};
      im.src=r.result};r.readAsDataURL(file)})
}
$('#file').addEventListener('change',function(e){
  var files=Array.prototype.slice.call(e.target.files).slice(0,6-imgs.length);e.target.value='';
  files.forEach(function(f){
    var idx=imgs.push('busy')-1;paintImgs();
    shrink(f).then(function(d){return api('upload','POST',{data:d})}).then(function(j){var k=imgs.indexOf('busy');imgs[k]=j.url;paintImgs()})
    .catch(function(er){var k=imgs.indexOf('busy');if(k>-1)imgs.splice(k,1);paintImgs();$('#perr').textContent=er.message});
  });
});
$('#pf').addEventListener('submit',function(e){
  e.preventDefault();var f=this;
  if(imgs.indexOf('busy')>-1){$('#perr').textContent='Wait for photos to finish uploading.';return}
  var body={name:f.name.value,price:f.price.value,stock:f.stock.value,category:f.category.value,description:f.description.value,images:imgs,active:f.active.checked};
  var b=$('#psave');b.disabled=true;
  api(editing?'products/'+editing:'products',editing?'PUT':'POST',body).then(function(){$('#pmodal').hidden=true;toast('Product saved');return refresh(false)})
  .catch(function(er){$('#perr').textContent=er.message}).then(function(){b.disabled=false});
});

/* ---- boot ---- */
api('me').then(showApp).catch(showLogin);
})();
