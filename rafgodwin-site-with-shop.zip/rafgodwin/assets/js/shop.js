(function(){'use strict';
var $=function(s,c){return(c||document).querySelector(s)};
var API='/api',KEY='rg_cart',WA=window.RG_WA||'233551120109';
var products=[],cart=load(),cat='',q='';
function load(){try{return JSON.parse(localStorage.getItem(KEY))||[]}catch(e){return[]}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(cart))}catch(e){}badge()}
function ghs(p){return 'GH\u20B5'+(p/100).toLocaleString('en-GH',{minimumFractionDigits:p%100?2:0,maximumFractionDigits:2})}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function img(u){return u?(u.charAt(0)==='/'?u:'/'+u):'/assets/img/logo-mark.png'}
function bgi(u){return "background-image:url('"+esc(img(u))+"')"}
function badge(){var n=cart.reduce(function(a,c){return a+c.qty},0);var b=$('#cartn');if(b)b.textContent=n;document.querySelectorAll('[data-cartc]').forEach(function(e){e.textContent=n;e.hidden=!n})}
function find(id){return products.filter(function(p){return p.id===id})[0]}

/* ---- grid ---- */
function render(){
  var cats=[];products.forEach(function(p){if(cats.indexOf(p.category)<0)cats.push(p.category)});
  var ch='<button data-c="" class="'+(cat?'':'on')+'">All</button>'+cats.map(function(c){return '<button data-c="'+esc(c)+'" class="'+(cat===c?'on':'')+'">'+esc(c)+'</button>'}).join('');
  $('#chips').innerHTML=ch;
  var list=products.filter(function(p){return(!cat||p.category===cat)&&(!q||(p.name+' '+p.description).toLowerCase().indexOf(q)>-1)});
  if(!list.length){$('#pgrid').innerHTML='<div class="empty" style="grid-column:1/-1"><h3>'+(products.length?'No products match your search':'Our online catalogue is being updated')+'</h3><p>Message us on <a href="https://wa.me/'+WA+'">WhatsApp</a> and we will help you right away.</p></div>';return}
  $('#pgrid').innerHTML=list.map(function(p){
    var tag=!p.in_stock?'<span class="tag out">Sold out</span>':p.low?'<span class="tag low">Few left</span>':'';
    return '<article class="pcard"><button class="pimg" data-v="'+p.id+'" style="'+bgi(p.images[0])+'" aria-label="View '+esc(p.name)+'">'+tag+'</button><div class="pbody"><span class="pcat">'+esc(p.category)+'</span><h3 data-v="'+p.id+'">'+esc(p.name)+'</h3><div class="pprice">'+ghs(p.price)+'</div>'
    +(p.in_stock?'<button class="btn btn-primary" data-add="'+p.id+'">Add to cart</button>':'<button class="btn btn-outline" disabled>Sold out</button>')+'</div></article>'}).join('');
}
function fetchProducts(){
  return fetch(API+'/products').then(function(r){return r.json()}).then(function(d){products=d.products||[];
    cart=cart.filter(function(c){return find(c.id)});save();render()}).catch(function(){$('#pgrid').innerHTML='<div class="empty" style="grid-column:1/-1"><h3>The shop could not load</h3><p>Please refresh, or order on <a href="https://wa.me/'+WA+'">WhatsApp</a>.</p></div>'});
}

/* ---- cart ---- */
function add(id,n){var p=find(id);if(!p||!p.in_stock)return;var c=cart.filter(function(x){return x.id===id})[0];if(c)c.qty=Math.min(99,c.qty+(n||1));else cart.push({id:id,qty:n||1});save();openDrawer('cart')}
function total(){return cart.reduce(function(a,c){var p=find(c.id);return a+(p?p.price*c.qty:0)},0)}
function openDrawer(view){$('#ov').classList.add('show');$('#drawer').classList.add('show');document.body.style.overflow='hidden';drawer(view)}
function closeAll(){$('#ov').classList.remove('show');$('#drawer').classList.remove('show');$('#pm').classList.remove('show');document.body.style.overflow=''}
function drawer(view){
  var h=$('#dh'),b=$('#db'),f=$('#df');
  if(view==='cart'){
    h.innerHTML='<h3>Your cart</h3><button class="x" data-close aria-label="Close">&times;</button>';
    if(!cart.length){b.innerHTML='<div class="empty"><p>Your cart is empty.</p></div>';f.hidden=true;return}
    b.innerHTML=cart.map(function(c){var p=find(c.id);return '<div class="line"><div class="th" style="'+bgi(p.images[0])+'"></div><div><b>'+esc(p.name)+'</b><small>'+ghs(p.price)+'</small><div class="qty"><button data-dec="'+c.id+'" aria-label="Less">&minus;</button><span>'+c.qty+'</span><button data-inc="'+c.id+'" aria-label="More">+</button></div></div><div style="text-align:right"><b>'+ghs(p.price*c.qty)+'</b><br><button class="rm" data-rm="'+c.id+'">Remove</button></div></div>'}).join('');
    f.hidden=false;f.innerHTML='<div class="tot"><span>Total</span><span>'+ghs(total())+'</span></div><button class="btn btn-primary" data-go="checkout">Checkout</button><p style="font-size:.78rem;margin-top:8px;text-align:center">Delivery cost is confirmed by our team when we call you.</p>';
  }else if(view==='checkout'){
    h.innerHTML='<h3>Checkout</h3><button class="x" data-close aria-label="Close">&times;</button>';
    b.innerHTML='<form class="cf" id="cf" novalidate><label>Full name *</label><input name="name" autocomplete="name" required><label>Phone / WhatsApp *</label><input name="phone" type="tel" autocomplete="tel" placeholder="024 000 0000" required><label>Email (optional)</label><input name="email" type="email" autocomplete="email"><label>Delivery address / landmark *</label><textarea name="address" required></textarea><label>Area / town</label><input name="area" placeholder="e.g. Sowutuom, Accra"><label>Payment</label><div class="pay"><label><input type="radio" name="payment" value="cod" checked><span>Pay on delivery or pickup</span></label><label><input type="radio" name="payment" value="momo"><span>Mobile Money &mdash; we send you the number after confirming</span></label></div><label>Notes (optional)</label><textarea name="notes"></textarea><div class="err-msg" id="cerr" role="alert"></div></form>';
    f.hidden=false;f.innerHTML='<div class="tot"><span>Total</span><span>'+ghs(total())+'</span></div><button class="btn btn-primary" id="place">Place order</button><button class="rm" data-go="cart" style="display:block;margin:10px auto 0">Back to cart</button>';
  }
}
function place(){
  var fm=$('#cf'),err=$('#cerr'),btn=$('#place');err.textContent='';
  var d={};new FormData(fm).forEach(function(v,k){d[k]=v});
  if(!d.name.trim()||d.phone.replace(/\D/g,'').length<9||d.address.trim().length<5){err.textContent='Please fill in your name, phone number and delivery address.';return}
  d.items=cart;btn.disabled=true;btn.textContent='Placing order...';
  fetch(API+'/checkout',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)})
  .then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||'Could not place order');return j})})
  .then(function(j){
    var lines=cart.map(function(c){var p=find(c.id);return '- '+c.qty+' x '+p.name}).join('\n');
    var msg='Hello RafGodwin Engineering, I just placed order '+j.code+' on your website.\n'+lines+'\nTotal: '+ghs(j.total)+'\nName: '+d.name;
    cart=[];save();
    $('#dh').innerHTML='<h3>Order received</h3><button class="x" data-close aria-label="Close">&times;</button>';
    $('#df').hidden=true;
    $('#db').innerHTML='<div class="done"><div class="ok">&#10003;</div><h3>Thank you, '+esc(d.name.split(' ')[0])+'!</h3><p style="margin:8px 0 14px">Your order number is</p><code>'+esc(j.code)+'</code><p style="margin-top:14px">Total '+ghs(j.total)+'. Our team will call or WhatsApp you shortly to confirm delivery'+(j.payment==='momo'?' and send the Mobile Money number':'')+'.</p><a class="btn btn-primary" target="_blank" rel="noopener" href="https://wa.me/'+WA+'?text='+encodeURIComponent(msg)+'">Send order details on WhatsApp</a><button class="btn btn-outline" data-close>Continue shopping</button></div>';
    fetchProducts();
  }).catch(function(e){err.textContent=e.message;btn.disabled=false;btn.textContent='Place order'});
}

/* ---- product modal ---- */
function view(id){
  var p=find(id);if(!p)return;var cur=0;
  function paint(){
    $('#pm-c').innerHTML='<button class="x" data-close aria-label="Close">&times;</button><div><div class="pm-img" style="'+bgi(p.images[cur])+'"></div>'+(p.images.length>1?'<div class="pm-thumbs">'+p.images.map(function(u,i){return '<i data-t="'+i+'" class="'+(i===cur?'on':'')+'" style="'+bgi(u)+'"></i>'}).join('')+'</div>':'')+'</div><div class="pm-info"><span class="pcat">'+esc(p.category)+'</span><h2 style="font-size:1.6rem">'+esc(p.name)+'</h2><div class="pprice" style="font-size:1.5rem;padding:0">'+ghs(p.price)+'</div><p>'+esc(p.description)+'</p>'+(p.in_stock?'<button class="btn btn-primary" data-add="'+p.id+'">Add to cart</button>':'<button class="btn btn-outline" disabled>Sold out</button>')+'<a class="btn btn-outline" target="_blank" rel="noopener" href="https://wa.me/'+WA+'?text='+encodeURIComponent('Hello, I have a question about: '+p.name)+'">Ask on WhatsApp</a></div>';
    $('#pm-c').querySelectorAll('[data-t]').forEach(function(t){t.onclick=function(){cur=+t.dataset.t;paint()}});
  }
  paint();$('#ov').classList.add('show');$('#pm').classList.add('show');document.body.style.overflow='hidden';
}

document.addEventListener('click',function(e){
  var t=e.target.closest('[data-c],[data-add],[data-v],[data-inc],[data-dec],[data-rm],[data-go],[data-close],#place,#ov,#cartbtn');if(!t)return;
  if(t.hasAttribute('data-c')&&t.parentNode.id==='chips'){cat=t.dataset.c;render()}
  else if(t.dataset.add){add(+t.dataset.add);$('#pm').classList.remove('show')}
  else if(t.dataset.v)view(+t.dataset.v);
  else if(t.dataset.inc){var c=cart.filter(function(x){return x.id==t.dataset.inc})[0];if(c&&c.qty<99){c.qty++;save();drawer('cart')}}
  else if(t.dataset.dec){var c2=cart.filter(function(x){return x.id==t.dataset.dec})[0];if(c2){c2.qty--;if(c2.qty<1)cart=cart.filter(function(x){return x!==c2});save();drawer('cart')}}
  else if(t.dataset.rm){cart=cart.filter(function(x){return x.id!=t.dataset.rm});save();drawer('cart')}
  else if(t.dataset.go)drawer(t.dataset.go);
  else if(t.id==='place')place();
  else if(t.id==='cartbtn')openDrawer('cart');
  else if(t.hasAttribute('data-close')||t.id==='ov')closeAll();
});
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeAll()});
$('#q').addEventListener('input',function(e){q=e.target.value.toLowerCase().trim();render()});
badge();fetchProducts();
})();
